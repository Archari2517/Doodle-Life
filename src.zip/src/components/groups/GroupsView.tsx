import React, { useState, useEffect } from 'react';
import { Users, Plus, UserPlus, CheckCircle2, XCircle, Calendar, ArrowLeft, Shield, Search, UserCheck, AlertCircle } from 'lucide-react';

// Import Firebase Config & Firestore Methods
import { db, auth } from '../../lib/firebase';
import { 
  collection, 
  query, 
  where, 
  getDocs, 
  doc, 
  updateDoc, 
  arrayUnion, 
  addDoc, 
  onSnapshot 
} from 'firebase/firestore';

// Interfaces
interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
}

interface GroupMember {
  id: string;
  name: string;
  email: string;
  role: 'Owner' | 'Member';
}

interface GroupTask {
  id: string;
  groupId: string;
  title: string;
  dueDate: string;
  sharedBy: string;
  creatorId: string; // เพิ่ม ID ของคนสร้างงาน
  responses?: { [userId: string]: 'ACCEPTED' | 'REJECTED' }; 
}

interface Group {
  id: string;
  name: string;
  description: string;
  membersCount: number;
  pendingTasksCount: number;
  members: GroupMember[];
}

export const GroupsView: React.FC = () => {
  // Main States
  const [groups, setGroups] = useState<Group[]>([]);
  const [tasks, setTasks] = useState<GroupTask[]>([]);
  const [selectedGroup, setSelectedGroup] = useState<Group | null>(null);

  // Modal States
  const [showCreateGroupModal, setShowCreateGroupModal] = useState(false);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [showAddTaskModal, setShowAddTaskModal] = useState(false);

  // Form States
  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupDesc, setNewGroupDesc] = useState('');
  const [taskTitle, setTaskTitle] = useState('');
  const [taskDueDate, setTaskDueDate] = useState('');
  const [activeTab, setActiveTab] = useState<'tasks' | 'members'>('tasks');

  // Search User States
  const [searchEmail, setSearchEmail] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [foundUser, setFoundUser] = useState<User | null>(null);
  const [searchError, setSearchError] = useState<string | null>(null);

  const currentUser = auth.currentUser;

  // -------------------------------------------------------------
  // 1. Real-time Fetch Groups จาก Firestore
  // -------------------------------------------------------------
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, 'groups'), (snapshot) => {
      const fetchedGroups: Group[] = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...(docSnap.data() as Omit<Group, 'id'>),
      }));
      setGroups(fetchedGroups);

      if (selectedGroup) {
        const updated = fetchedGroups.find((g) => g.id === selectedGroup.id);
        if (updated) setSelectedGroup(updated);
      }
    });

    return () => unsubscribe();
  }, [selectedGroup?.id]);

  // -------------------------------------------------------------
  // 2. Real-time Fetch Tasks ของกลุ่มที่เลือกจาก Firestore
  // -------------------------------------------------------------
  useEffect(() => {
    if (!selectedGroup) return;

    const q = query(collection(db, 'groupTasks'), where('groupId', '==', selectedGroup.id));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const fetchedTasks: GroupTask[] = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...(docSnap.data() as Omit<GroupTask, 'id'>),
      }));
      setTasks(fetchedTasks);
    });

    return () => unsubscribe();
  }, [selectedGroup]);

  // -------------------------------------------------------------
  // 3. Search User ใน Firestore
  // -------------------------------------------------------------
  useEffect(() => {
    if (!searchEmail.trim()) {
      setFoundUser(null);
      setSearchError(null);
      setIsSearching(false);
      return;
    }

    setIsSearching(true);
    setSearchError(null);

    const timer = setTimeout(async () => {
      try {
        const q = query(
          collection(db, 'users'),
          where('email', '==', searchEmail.trim().toLowerCase())
        );
        const querySnapshot = await getDocs(q);

        if (!querySnapshot.empty) {
          const userDoc = querySnapshot.docs[0];
          const userData = {
            id: userDoc.id,
            name: userDoc.data().name || userDoc.data().displayName || 'Unknown',
            email: userDoc.data().email,
            avatarUrl: userDoc.data().avatarUrl,
          };

          const isAlreadyMember = selectedGroup?.members.some((m) => m.email === userData.email);
          if (isAlreadyMember) {
            setSearchError('ผู้ใช้นี้เป็นสมาชิกในกลุ่มนี้อยู่แล้ว');
            setFoundUser(null);
          } else {
            setFoundUser(userData);
            setSearchError(null);
          }
        } else {
          setFoundUser(null);
          setSearchError('ไม่พบผู้ใช้งานด้วย Email นี้ในระบบ');
        }
      } catch (error) {
        console.error('Error searching user:', error);
        setSearchError('เกิดข้อผิดพลาดในการค้นหาข้อมูล');
      } finally {
        setIsSearching(false);
      }
    }, 400);

    return () => clearTimeout(timer);
  }, [searchEmail, selectedGroup]);

  // -------------------------------------------------------------
  // Handlers
  // -------------------------------------------------------------
  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName.trim()) return;

    try {
      const newGroupData = {
        name: newGroupName,
        description: newGroupDesc,
        membersCount: 1,
        pendingTasksCount: 0,
        members: [
          { 
            id: currentUser?.uid || 'me', 
            name: currentUser?.displayName || currentUser?.email?.split('@')[0] || 'คุณ (Me)', 
            email: currentUser?.email || 'you@example.com', 
            role: 'Owner' 
          }
        ]
      };

      await addDoc(collection(db, 'groups'), newGroupData);
      setNewGroupName('');
      setNewGroupDesc('');
      setShowCreateGroupModal(false);
    } catch (error) {
      console.error('Error creating group:', error);
      alert('เกิดข้อผิดพลาดในการสร้างกลุ่ม');
    }
  };

  const handleConfirmInvite = async () => {
    if (!foundUser || !selectedGroup) return;

    const newMember: GroupMember = {
      id: foundUser.id,
      name: foundUser.name,
      email: foundUser.email,
      role: 'Member'
    };

    try {
      const groupRef = doc(db, 'groups', selectedGroup.id);
      await updateDoc(groupRef, {
        membersCount: (selectedGroup.membersCount || 0) + 1,
        members: arrayUnion(newMember)
      });

      setSearchEmail('');
      setFoundUser(null);
      setShowInviteModal(false);
    } catch (error) {
      console.error('Error adding member:', error);
      alert('เกิดข้อผิดพลาดในการเพิ่มสมาชิก');
    }
  };

  // บันทึกงานใหม่ลงกลุ่มบน Firestore
  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskTitle.trim() || !selectedGroup || !currentUser) return;

    try {
      // ตั้งค่าให้คนที่สร้างงาน เป็นคนกด ACCEPTED โดยอัตโนมัติ
      const initialResponses = {
        [currentUser.uid]: 'ACCEPTED' as const
      };

      await addDoc(collection(db, 'groupTasks'), {
        groupId: selectedGroup.id,
        title: taskTitle,
        dueDate: taskDueDate || 'ไม่ระบุวันส่ง',
        sharedBy: currentUser.displayName || currentUser.email?.split('@')[0] || 'สมาชิกในกลุ่ม',
        creatorId: currentUser.uid,
        responses: initialResponses
      });

      setTaskTitle('');
      setTaskDueDate('');
      setShowAddTaskModal(false);
    } catch (error) {
      console.error('Error adding task:', error);
      alert('เกิดข้อผิดพลาดในการสร้างงาน');
    }
  };

  // สมาชิกกดตอบรับ (Accept) หรือ ปฏิเสธ (Reject) งาน
  const handleTaskResponse = async (taskId: string, status: 'ACCEPTED' | 'REJECTED') => {
    if (!currentUser) {
      alert('กรุณาล็อกอินก่อนทำการตอบรับงาน');
      return;
    }

    try {
      const taskRef = doc(db, 'groupTasks', taskId);
      await updateDoc(taskRef, {
        [`responses.${currentUser.uid}`]: status
      });
    } catch (error) {
      console.error('Error updating task response:', error);
      alert('ไม่สามารถอัปเดตสถานะได้');
    }
  };

  return (
    <div className="p-4 md:p-6 max-w-4xl mx-auto space-y-6">
      
      {/* 1. หน้าหลัก: รายการกลุ่มทั้งหมด */}
      {!selectedGroup ? (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-slate-800">กลุ่มของฉัน</h1>
              <p className="text-slate-500 text-sm">จัดการกลุ่มและแชร์รายการงานร่วมกับเพื่อน</p>
            </div>
            <button
              onClick={() => setShowCreateGroupModal(true)}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl text-sm font-medium transition-all shadow-sm"
            >
              <Plus size={18} />
              สร้างกลุ่มใหม่
            </button>
          </div>

          {groups.length === 0 ? (
            <div className="bg-white p-12 text-center rounded-2xl border border-dashed border-slate-300 space-y-3">
              <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mx-auto">
                <Users size={24} />
              </div>
              <h3 className="font-semibold text-slate-700">ยังไม่มีกลุ่มในระบบ</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                เริ่มต้นด้วยการสร้างกลุ่มใหม่เพื่อแชร์งาน และทำงานร่วมกับเพื่อนของคุณ
              </p>
              <button
                onClick={() => setShowCreateGroupModal(true)}
                className="mt-2 inline-flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-indigo-700 transition-all"
              >
                <Plus size={16} />
                สร้างกลุ่มแรกของคุณ
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {groups.map((group) => (
                <div
                  key={group.id}
                  onClick={() => setSelectedGroup(group)}
                  className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:border-indigo-300 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
                >
                  <div>
                    <h3 className="font-semibold text-lg text-slate-800 mb-1">{group.name}</h3>
                    <p className="text-slate-500 text-sm mb-4 line-clamp-2">
                      {group.description || 'ไม่มีคำอธิบายกลุ่ม'}
                    </p>
                  </div>

                  <div className="flex justify-between items-center pt-3 border-t border-slate-100 text-slate-500 text-xs">
                    <span className="flex items-center gap-1">
                      <Users size={14} />
                      {group.members?.length || 0} สมาชิก
                    </span>
                    <span className="text-indigo-600 font-medium">เข้าดูรายละเอียด →</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (

      /* 2. หน้ารายละเอียดกลุ่มที่เลือก */
        <div className="space-y-6">
          <button
            onClick={() => setSelectedGroup(null)}
            className="flex items-center gap-1 text-slate-500 hover:text-slate-800 text-sm transition-colors"
          >
            <ArrowLeft size={16} />
            ย้อนกลับไปหน้ากลุ่มทั้งหมด
          </button>

          {/* Group Header Card */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl font-bold text-slate-800">{selectedGroup.name}</h1>
                <p className="text-slate-500 text-sm mt-1">{selectedGroup.description || 'ไม่มีคำอธิบายกลุ่ม'}</p>
              </div>
              <button
                onClick={() => {
                  setSearchEmail('');
                  setFoundUser(null);
                  setSearchError(null);
                  setShowInviteModal(true);
                }}
                className="flex items-center justify-center gap-2 border border-slate-300 hover:bg-slate-50 px-4 py-2 rounded-xl text-sm font-medium transition-all"
              >
                <UserPlus size={16} />
                เชิญเพื่อนเข้ากลุ่ม
              </button>
            </div>

            {/* Navigation Tabs */}
            <div className="flex gap-6 border-b border-slate-200 mt-6">
              <button
                onClick={() => setActiveTab('tasks')}
                className={`pb-2 text-sm font-medium border-b-2 transition-all ${
                  activeTab === 'tasks'
                    ? 'border-indigo-600 text-indigo-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                รายการงานในกลุ่ม ({tasks.length})
              </button>
              <button
                onClick={() => setActiveTab('members')}
                className={`pb-2 text-sm font-medium border-b-2 transition-all ${
                  activeTab === 'members'
                    ? 'border-indigo-600 text-indigo-600'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                สมาชิก ({selectedGroup.members?.length || 0})
              </button>
            </div>
          </div>

          {/* Tab Content: งานในกลุ่ม */}
          {activeTab === 'tasks' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="font-semibold text-slate-700">งานที่แชร์ร่วมกัน</h3>
                <button 
                  onClick={() => setShowAddTaskModal(true)}
                  className="bg-indigo-600 text-white px-3.5 py-1.5 rounded-xl text-sm font-medium hover:bg-indigo-700 transition-all flex items-center gap-1.5"
                >
                  <Plus size={16} />
                  เพิ่มงานในกลุ่ม
                </button>
              </div>

              {tasks.length === 0 ? (
                <div className="bg-white p-8 text-center rounded-2xl border border-slate-200 text-slate-400">
                  ยังไม่มีงานที่ถูกเพิ่มในกลุ่มนี้ กดปุ่ม "+ เพิ่มงานในกลุ่ม" เพื่อเริ่มสร้างงาน
                </div>
              ) : (
                tasks.map((task) => {
                  const isCreator = currentUser?.uid === task.creatorId;
                  const myStatus = currentUser ? task.responses?.[currentUser.uid] : undefined;

                  return (
                    <div key={task.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div>
                        <h4 className="font-medium text-slate-800 text-base">{task.title}</h4>
                        <div className="flex items-center gap-4 text-xs text-slate-500 mt-2">
                          <span className="flex items-center gap-1">
                            <Calendar size={13} /> กำหนดส่ง: {task.dueDate}
                          </span>
                          <span>สร้างโดย: {task.sharedBy}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {/* 1. กรณีเป็นคนที่สร้างงานเอง -> แสดงว่าสร้างแล้ว (ไม่ต้องกดอะไร) */}
                        {isCreator ? (
                          <span className="inline-flex items-center gap-1 text-xs text-indigo-600 bg-indigo-50 px-3 py-1.5 rounded-full font-medium">
                            <CheckCircle2 size={14} /> คุณสร้างงานนี้แล้ว
                          </span>
                        ) : (
                          /* 2. กรณีเป็นเพื่อนในกลุ่ม -> แสดงปุ่มให้กดยืนยัน หรือปุ่มสถานะ */
                          <>
                            {!myStatus && (
                              <>
                                <button
                                  onClick={() => handleTaskResponse(task.id, 'ACCEPTED')}
                                  className="flex items-center gap-1 bg-emerald-50 text-emerald-600 hover:bg-emerald-100 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
                                >
                                  <CheckCircle2 size={14} /> ยืนยันรับงาน
                                </button>
                                <button
                                  onClick={() => handleTaskResponse(task.id, 'REJECTED')}
                                  className="flex items-center gap-1 bg-rose-50 text-rose-600 hover:bg-rose-100 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
                                >
                                  <XCircle size={14} /> ไม่ยืนยัน
                                </button>
                              </>
                            )}

                            {myStatus === 'ACCEPTED' && (
                              <div className="flex items-center gap-2">
                                <span className="inline-flex items-center gap-1 text-xs text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full font-medium">
                                  <CheckCircle2 size={13} /> คุณยืนยันงานนี้แล้ว
                                </span>
                                <button 
                                  onClick={() => handleTaskResponse(task.id, 'REJECTED')}
                                  className="text-xs text-slate-400 hover:text-rose-500 underline"
                                >
                                  เปลี่ยนใจ
                                </button>
                              </div>
                            )}

                            {myStatus === 'REJECTED' && (
                              <div className="flex items-center gap-2">
                                <span className="inline-flex items-center gap-1 text-xs text-rose-500 bg-rose-50 px-3 py-1 rounded-full font-medium">
                                  <XCircle size={13} /> คุณไม่ยืนยันงานนี้
                                </span>
                                <button 
                                  onClick={() => handleTaskResponse(task.id, 'ACCEPTED')}
                                  className="text-xs text-slate-400 hover:text-emerald-600 underline"
                                >
                                  เปลี่ยนใจ
                                </button>
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* Tab Content: สมาชิกในกลุ่ม */}
          {activeTab === 'members' && (
            <div className="bg-white rounded-2xl border border-slate-200 divide-y divide-slate-100 overflow-hidden">
              {selectedGroup.members?.map((member) => (
                <div key={member.id || member.email} className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-600 font-bold flex items-center justify-center text-sm">
                      {(member.name || member.email).charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-slate-800">{member.name}</p>
                      <p className="text-xs text-slate-400">{member.email}</p>
                    </div>
                  </div>
                  <span className={`text-xs px-2.5 py-1 rounded-full flex items-center gap-1 ${
                    member.role === 'Owner' 
                      ? 'bg-indigo-50 text-indigo-600 font-medium' 
                      : 'bg-slate-100 text-slate-500'
                  }`}>
                    {member.role === 'Owner' && <Shield size={12} />}
                    {member.role}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Modal 1: สร้างกลุ่มใหม่ */}
      {showCreateGroupModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white w-full max-w-md rounded-2xl p-6 shadow-xl">
            <h2 className="text-lg font-bold text-slate-800 mb-4">สร้างกลุ่มใหม่</h2>
            <form onSubmit={handleCreateGroup} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">ชื่อกลุ่ม *</label>
                <input
                  type="text"
                  required
                  placeholder="เช่น แก๊งโปรเจกต์ Todo App"
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  className="w-full px-3.5 py-2 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">คำอธิบายกลุ่ม</label>
                <textarea
                  placeholder="ระบุวัตถุประสงค์หรือรายละเอียดสั้นๆ..."
                  value={newGroupDesc}
                  onChange={(e) => setNewGroupDesc(e.target.value)}
                  className="w-full px-3.5 py-2 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 h-20 resize-none"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateGroupModal(false)}
                  className="px-4 py-2 rounded-xl text-sm text-slate-500 hover:bg-slate-100"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-sm bg-indigo-600 text-white font-medium hover:bg-indigo-700"
                >
                  ยืนยันสร้างกลุ่ม
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: เพิ่มงานในกลุ่ม */}
      {showAddTaskModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white w-full max-w-md rounded-2xl p-6 shadow-xl">
            <h2 className="text-lg font-bold text-slate-800 mb-4">เพิ่มงานใหม่ในกลุ่ม</h2>
            <form onSubmit={handleCreateTask} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">ชื่อหัวข้องาน *</label>
                <input
                  type="text"
                  required
                  placeholder="เช่น ส่งรายงาน Mini Project"
                  value={taskTitle}
                  onChange={(e) => setTaskTitle(e.target.value)}
                  className="w-full px-3.5 py-2 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">กำหนดส่ง (Due Date)</label>
                <input
                  type="date"
                  value={taskDueDate}
                  onChange={(e) => setTaskDueDate(e.target.value)}
                  className="w-full px-3.5 py-2 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddTaskModal(false)}
                  className="px-4 py-2 rounded-xl text-sm text-slate-500 hover:bg-slate-100"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-sm bg-indigo-600 text-white font-medium hover:bg-indigo-700"
                >
                  เพิ่มงาน
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 3: เชิญเพื่อนเข้ากลุ่ม */}
      {showInviteModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white w-full max-w-md rounded-2xl p-6 shadow-xl space-y-4">
            <div>
              <h2 className="text-lg font-bold text-slate-800 mb-1">ค้นหาและเชิญเพื่อน</h2>
              <p className="text-xs text-slate-500">พิมพ์ Email ของเพื่อนเพื่อค้นหาบัญชีผู้ใช้ในระบบ</p>
            </div>

            <div className="relative">
              <Search className="absolute left-3.5 top-2.5 text-slate-400" size={18} />
              <input
                type="email"
                placeholder="ป้อนอีเมลเพื่อนที่สมัครในระบบ..."
                value={searchEmail}
                onChange={(e) => setSearchEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {isSearching && (
              <p className="text-xs text-slate-400 text-center py-2 animate-pulse">
                กำลังค้นหาข้อมูลผู้ใช้ในระบบ...
              </p>
            )}

            {searchError && (
              <div className="flex items-center gap-2 text-rose-600 bg-rose-50 p-3 rounded-xl text-xs font-medium border border-rose-100">
                <AlertCircle size={16} className="shrink-0" />
                <span>{searchError}</span>
              </div>
            )}

            {foundUser && (
              <div className="bg-indigo-50/60 p-4 rounded-xl border border-indigo-100 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-sm">
                    {(foundUser.name || foundUser.email).charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{foundUser.name}</p>
                    <p className="text-xs text-slate-500">{foundUser.email}</p>
                  </div>
                </div>
                <span className="inline-flex items-center gap-1 text-[11px] text-emerald-600 font-medium bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  <UserCheck size={12} /> พบบัญชี
                </span>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowInviteModal(false)}
                className="px-4 py-2 rounded-xl text-sm text-slate-500 hover:bg-slate-100"
              >
                ยกเลิก
              </button>
              <button
                type="button"
                disabled={!foundUser}
                onClick={handleConfirmInvite}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                  foundUser
                    ? 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-sm'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                เพิ่มเข้ากลุ่ม
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};